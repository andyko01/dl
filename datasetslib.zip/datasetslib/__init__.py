from .utils import nputil
from .utils import tfutil
from .utils import imutil


datasets_root = './datasets'
